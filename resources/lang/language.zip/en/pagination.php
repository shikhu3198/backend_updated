<?php 

return [
    'next' => 'Next »',
    'previous' => '« Previous',
];